//C:\Users\lucas\OneDrive\Desktop\APILogin> nodemon server.js

//Dependências
//npm init -y
//npm install express mysql2 dotenv
//npm install mysql2 fs
//npm install cors
//npm install multer
//npm install -g nodemon

const cors = require('cors');

const express = require('express');
const app = express();
const db = require('./db');
require('dotenv').config();

app.use(express.json());
app.use(cors())

const PORT = process.env.PORT || 3000;

const imagem = fs.readFileSync("uploads/foto.jpg");
const multer = require('multer');
const fs = require('fs');

// Configuração do multer (salva no diretório temporário "uploads/")
const upload = multer({ dest: 'uploads/' });

// Rota GET - Listar usuários
app.get('/usuarios', (req, res) => {
  db.query('SELECT * FROM cliente', (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
});

// Rota POST - Criar novo usuário
app.post('/usuarios', (req, res) => {
  const {nome ,conteudo} = req.body;

  if (!nome || !conteudo ) {
    return res.status(400).json({ error: 'login e senha são obrigatórios' });
  }

  const sql = 'INSERT INTO foto(nome ,conteudo) VALUES (?,?)';
  db.query(sql, [nome ,conteudo], (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    if (results.length === 0) {
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    // Login bem-sucedido
    const user = results[0];
    res.json({
      message: 'cadastro feito',
      user: { 
        nome: nome, 
        conteudo: conteudo,
      }
    });
  });
});

// PUT para atualizar a imagem de um registro existente
app.put('/upload/:id', upload.single('foto'), (req, res) => {
  const { id } = req.params;

  if (!req.file) {
    return res.status(400).json({ mensagem: 'Nenhuma imagem enviada.' });
  }

  // Lê o arquivo enviado
  const imagem = fs.readFileSync(req.file.path);

  // Atualiza no banco
  const sql = 'UPDATE foto SET foto = ? WHERE id = ?';
  db.query(sql, [imagem, id], (err, result) => {
    if (err) {
      console.error('Erro ao salvar no banco:', err);
      return res.status(500).json({ mensagem: 'Erro interno no servidor.' });
    }

    // Remove o arquivo temporário do uploads/
    fs.unlinkSync(req.file.path);

    res.json({ mensagem: 'Imagem atualizada com sucesso!', id });
  });
});



// Inicializa o servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});


