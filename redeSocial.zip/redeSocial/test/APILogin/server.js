//C:\Users\lucas\OneDrive\Desktop\APILogin> nodemon server.js

//Dependências
//npm init -y
//npm install express mysql2 dotenv
//npm install mysql2 fs
//npm install cors
//npm install multer
//npm install -g nodemon

const cors = require('cors');
const express = require('express');
const app = express();
const db = require('./db');
const fs = require('fs');
const multer = require('multer');
require('dotenv').config();

app.use(express.json());
app.use(cors());

const PORT = process.env.PORT || 3000;

// Configuração do multer (armazenamento temporário)
const upload = multer({ dest: 'uploads/' });

app.post('/pool', upload.single('foto'), (req, res) => {
  const { nome } = req.body;

  if (!req.file) {
    return res.status(400).json({ mensagem: 'Nenhuma imagem foi enviada.' });
  }


  const imagem = fs.readFileSync(req.file.path);


 
  const sql = 'INSERT INTO imagens (nome, foto) VALUES (?, ?)';
  db.query(sql, [nome, imagem], (err, result) => {
    if (err) {
      console.error('Erro ao salvar no banco:', err);
      return res.status(500).json({ mensagem: 'Erro interno no servidor.' });
    }

    // Remove o arquivo temporário
    fs.unlinkSync(req.file.path);

    res.status(201).json({
      mensagem: 'Imagem salva com sucesso!',
      id: result.insertId,
      nome: nome
    });
  });
});

app.post('/imagens/:id', (req, res) => {
  const { id } = req.params;

  const sql = 'SELECT nome, foto FROM imagens WHERE idImagens = ?';
  db.query(sql, [id], (err, results) => {
    if (err) {
      console.error('Erro ao buscar imagem:', err);
      return res.status(500).json({ mensagem: 'Erro interno no servidor.' });
    }

    if (results.length === 0) {
      return res.status(404).json({ mensagem: 'Imagem não encontrada.' });
    }

    const imagem = results[0];
    res.setHeader('Content-Type', 'image/jpeg');
    res.send(imagem.foto);
  });
});

// Rota GET - Listar usuários
app.get('/usuarios', (req, res) => {
  db.query('SELECT * FROM cliente', (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
});

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
