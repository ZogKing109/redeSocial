/*
Dependências
npm init -y
npm install express cors multer mysql2 dotenv
npm install -g nodemon
*/

const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const db = require('./db');
require('dotenv').config();

const app = express();

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

const PORT = process.env.PORT || 3000;

// Usaremos multer em memória para gravar imagens direto no banco (BLOB)
const storage = multer.memoryStorage();
const upload = multer({ storage });

// Rota para inserir nova imagem no banco (espera campo 'nome' e arquivo 'foto')
app.post('/pool', upload.single('foto'), (req, res) => {
  const nome = req.body.nome || null;

  if (!req.file) {
    return res.status(400).json({ mensagem: 'Nenhuma imagem foi enviada.' });
  }

  const imagemBuffer = req.file.buffer;

  const sql = 'INSERT INTO imagens (nome, foto) VALUES (?, ?)';
  db.query(sql, [nome, imagemBuffer], (err, result) => {
    if (err) {
      console.error('Erro ao salvar no banco:', err);
      return res.status(500).json({ mensagem: 'Erro interno no servidor.' });
    }

    res.status(201).json({ mensagem: 'Imagem salva com sucesso!', id: result.insertId, nome });
  });
});

// Rota para atualizar imagem existente (PUT /upload/:id)
app.put('/upload/:id', upload.single('foto'), (req, res) => {
  const { id } = req.params;

  if (!req.file) {
    return res.status(400).json({ mensagem: 'Nenhuma imagem enviada para atualização.' });
  }

  const imagemBuffer = req.file.buffer;
  const sql = 'UPDATE imagens SET foto = ? WHERE idImagens = ?';
  db.query(sql, [imagemBuffer, id], (err, result) => {
    if (err) {
      console.error('Erro ao atualizar imagem:', err);
      return res.status(500).json({ mensagem: 'Erro interno no servidor.' });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ mensagem: 'Imagem não encontrada.' });
    }
    res.json({ mensagem: 'Imagem atualizada com sucesso.' });
  });
});

// Rota para buscar imagem por id e retornar como base64 (GET /imagem/:id)
app.get('/imagem/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'SELECT nome, foto FROM imagens WHERE idImagens = ?';
  db.query(sql, [id], (err, results) => {
    if (err) {
      console.error('Erro ao buscar imagem:', err);
      return res.status(500).json({ mensagem: 'Erro interno no servidor.' });
    }
    if (results.length === 0) {
      return res.status(404).json({ mensagem: 'Imagem não encontrada.' });
    }

    const row = results[0];
    const imagemBuffer = row.foto;
    // Retornar JSON com a imagem em base64 (o front-end já espera isso no app.js)
    res.json({ nome: row.nome, imagem: `data:image/jpeg;base64,${imagemBuffer.toString('base64')}` });
  });
});

// Rota GET - Listar usuários
app.get('/usuarios', (req, res) => {
  db.query('SELECT * FROM cliente', (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
});

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
